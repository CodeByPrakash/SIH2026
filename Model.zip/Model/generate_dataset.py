"""
MPLADS-SATHI: Extended All-States Dataset Generator
====================================================
Generates a comprehensive, cleaned dataset covering all 36 States/UTs of India
with 15,000+ synthetic works calibrated against real MPLADS allocation data.

Outputs:
  - dataset/mplads_mp_table.csv       (542 MPs with utilization & risk profiles)
  - dataset/mplads_work_table.csv     (15,000 works with ML-ready features)
  - dataset/mplads_mp_risk_leaderboard.csv  (Ranked MP risk leaderboard)
"""

import numpy as np
import pandas as pd
import os
import warnings
warnings.filterwarnings("ignore")

# Fix pandas 3.0 ArrowDtype string truncation
pd.options.future.infer_string = False


# ─── Reproducibility ─────────────────────────────────────────────────────────
np.random.seed(42)

# ─── Configuration ────────────────────────────────────────────────────────────
NUM_WORKS = 15000
ANOMALY_RATIO = 0.635   # 63.5% anomalous (CAG audit calibration)
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dataset")

# ─── Anomaly Distribution (calibrated to CAG reports) ─────────────────────────
ANOMALY_TYPES = {
    "delay_anomaly":   0.3345,  # ~3,189 works
    "cost_anomaly":    0.2471,  # ~2,355 works
    "duplicate_work":  0.1764,  # ~1,682 works
    "ghost_asset":     0.1045,  # ~996 works
    "vendor_anomaly":  0.0851,  # ~811 works
    "payment_anomaly": 0.0523,  # ~498 works
}

# ─── All States/UTs of India ─────────────────────────────────────────────────
STATES_AND_UTS = {
    "Andhra Pradesh":       {"seats": 25, "districts": ["Anantapur", "Chittoor", "Guntur", "Kadapa", "Krishna", "Kurnool", "Nellore", "Prakasam", "Srikakulam", "Visakhapatnam", "Vizianagaram", "West Godavari", "East Godavari"]},
    "Arunachal Pradesh":    {"seats": 2,  "districts": ["Itanagar", "Tawang", "Ziro", "Pasighat"]},
    "Assam":                {"seats": 14, "districts": ["Guwahati", "Jorhat", "Dibrugarh", "Silchar", "Nagaon", "Tezpur", "Barpeta", "Karimganj", "Kokrajhar", "Dhubri"]},
    "Bihar":                {"seats": 40, "districts": ["Patna", "Gaya", "Muzaffarpur", "Bhagalpur", "Darbhanga", "Purnia", "Arrah", "Begusarai", "Nalanda", "Madhubani", "Sitamarhi", "Nawada", "Sasaram", "Buxar", "Munger", "Samastipur", "Hajipur", "Siwan", "Saran"]},
    "Chhattisgarh":         {"seats": 11, "districts": ["Raipur", "Bilaspur", "Durg", "Korba", "Rajnandgaon", "Bastar", "Janjgir-Champa", "Raigarh", "Mahasamund", "Kanker", "Sarguja"]},
    "Goa":                  {"seats": 2,  "districts": ["North Goa", "South Goa"]},
    "Gujarat":              {"seats": 26, "districts": ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar", "Jamnagar", "Junagadh", "Anand", "Kheda", "Navsari", "Bharuch", "Patan", "Banaskantha", "Porbandar", "Kachchh", "Dahod", "Chhota Udaipur"]},
    "Haryana":              {"seats": 10, "districts": ["Gurgaon", "Faridabad", "Karnal", "Rohtak", "Hisar", "Ambala", "Kurukshetra", "Sonepat", "Sirsa", "Bhiwani"]},
    "Himachal Pradesh":     {"seats": 4,  "districts": ["Shimla", "Mandi", "Kangra", "Hamirpur"]},
    "Jharkhand":            {"seats": 14, "districts": ["Ranchi", "Jamshedpur", "Dhanbad", "Hazaribagh", "Bokaro", "Giridih", "Dumka", "Godda", "Kodarma", "Khunti", "Singhbhum", "Palamu", "Lohardaga", "Rajmahal"]},
    "Karnataka":            {"seats": 28, "districts": ["Bangalore", "Mysore", "Belgaum", "Hubli-Dharwad", "Mangalore", "Shimoga", "Bellary", "Gulbarga", "Raichur", "Davangere", "Hassan", "Tumkur", "Bidar", "Chitradurga", "Udupi", "Koppal", "Kolar", "Chikmagalur", "Chamarajanagar"]},
    "Kerala":               {"seats": 20, "districts": ["Thiruvananthapuram", "Kochi", "Kozhikode", "Thrissur", "Kollam", "Kannur", "Alappuzha", "Palakkad", "Malappuram", "Kottayam", "Idukki", "Wayanad", "Kasaragod", "Pathanamthitta"]},
    "Madhya Pradesh":       {"seats": 29, "districts": ["Bhopal", "Indore", "Gwalior", "Jabalpur", "Ujjain", "Sagar", "Rewa", "Satna", "Dewas", "Khandwa", "Chhindwara", "Ratlam", "Hoshangabad", "Betul", "Mandla", "Khajuraho", "Vidisha", "Mandsour", "Rajgarh", "Sidhi", "Damoh", "Morena", "Bhind", "Shahdol", "Dhar"]},
    "Maharashtra":          {"seats": 48, "districts": ["Mumbai", "Pune", "Nagpur", "Thane", "Nashik", "Aurangabad", "Solapur", "Kolhapur", "Satara", "Sangli", "Nanded", "Latur", "Akola", "Amravati", "Wardha", "Beed", "Jalgaon", "Raigad", "Ratnagiri", "Palghar", "Chandrapur", "Gadchiroli", "Bhandara", "Shirur", "Maval", "Baramati"]},
    "Manipur":              {"seats": 2,  "districts": ["Imphal East", "Imphal West", "Churachandpur", "Thoubal"]},
    "Meghalaya":            {"seats": 2,  "districts": ["Shillong", "Tura"]},
    "Mizoram":              {"seats": 1,  "districts": ["Aizawl"]},
    "Nagaland":             {"seats": 1,  "districts": ["Kohima", "Dimapur"]},
    "Odisha":               {"seats": 21, "districts": ["Bhubaneswar", "Cuttack", "Puri", "Berhampur", "Sambalpur", "Rourkela", "Balasore", "Bhadrak", "Jajpur", "Kendrapara", "Kalahandi", "Koraput", "Mayurbhanj", "Nabarangpur", "Sundargarh", "Bargarh", "Dhenkanal", "Kandhamal", "Jagatsinghpur", "Bolangir", "Keonjhar"]},
    "Punjab":               {"seats": 13, "districts": ["Ludhiana", "Amritsar", "Jalandhar", "Patiala", "Bhatinda", "Sangrur", "Hoshiarpur", "Gurdaspur", "Firozpur", "Faridkot", "Fatehgarh Sahib", "Anandpur Sahib"]},
    "Rajasthan":            {"seats": 25, "districts": ["Jaipur", "Jodhpur", "Udaipur", "Kota", "Ajmer", "Bikaner", "Alwar", "Sikar", "Bhilwara", "Chittorgarh", "Pali", "Churu", "Jhunjhunu", "Nagaur", "Barmer", "Jalore", "Banswara", "Rajsamand", "Jhalawar-Baran", "Tonk", "Dausa", "Ganganagar", "Karauli-Dholpur", "Bharatpur"]},
    "Sikkim":               {"seats": 1,  "districts": ["Gangtok"]},
    "Tamil Nadu":           {"seats": 39, "districts": ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem", "Tirunelveli", "Erode", "Vellore", "Tiruppur", "Thanjavur", "Dindigul", "Theni", "Pollachi", "Krishnagiri", "Perambalur", "Cuddalore", "Nagapattinam", "Sivaganga", "Ramanathapuram", "Virudhunagar", "Thoothukudi", "Kancheepuram", "Arakkonam", "Namakkal", "Mayiladuthurai", "Karur", "Nilgiris", "Kallakurichi", "Dharamapuri", "Villupuram", "Sriperumbudur"]},
    "Telangana":            {"seats": 17, "districts": ["Hyderabad", "Warangal", "Karimnagar", "Nizamabad", "Khammam", "Mahabubnagar", "Nalgonda", "Medak", "Adilabad", "Secunderabad", "Malkajgiri", "Bhongir", "Peddapalle", "Zahirabad", "Nagarkurnool", "Chelvella", "Mahabubabad"]},
    "Tripura":              {"seats": 2,  "districts": ["Agartala", "Dharmanagar"]},
    "Uttar Pradesh":        {"seats": 80, "districts": ["Lucknow", "Varanasi", "Agra", "Kanpur", "Meerut", "Allahabad", "Ghaziabad", "Noida", "Bareilly", "Moradabad", "Aligarh", "Gorakhpur", "Jhansi", "Mathura", "Firozabad", "Sultanpur", "Faizabad", "Basti", "Gonda", "Bahraich", "Sitapur", "Hardoi", "Shahjahanpur", "Pilibhit", "Etawah", "Farrukhabad", "Jaunpur", "Azamgarh", "Deoria", "Ballia", "Saharanpur", "Muzaffarnagar", "Bijnor", "Amroha", "Rampur", "Sambhal", "Budaun", "Unnao", "Rae Bareli", "Amethi"]},
    "Uttarakhand":          {"seats": 5,  "districts": ["Dehradun", "Haridwar", "Nainital", "Almora", "Tehri Garhwal"]},
    "West Bengal":          {"seats": 42, "districts": ["Kolkata", "Howrah", "Darjeeling", "Siliguri", "Asansol", "Durgapur", "Bardhaman", "Midnapore", "Bankura", "Birbhum", "Purulia", "Malda", "Murshidabad", "Nadia", "Hooghly", "Barasat", "Basirhat", "Diamond Harbour", "Raiganj", "Jalpaiguri", "Alipurduar", "Cooch Behar", "Bolpur", "Tamluk"]},
    # Union Territories
    "Andaman And Nicobar Islands": {"seats": 1, "districts": ["Port Blair"]},
    "Chandigarh":           {"seats": 1,  "districts": ["Chandigarh"]},
    "The Dadra And Nagar Haveli And Daman And Diu": {"seats": 2, "districts": ["Silvassa", "Daman"]},
    "Delhi":                {"seats": 7,  "districts": ["New Delhi", "North Delhi", "South Delhi", "East Delhi", "West Delhi", "Central Delhi"]},
    "Jammu And Kashmir":    {"seats": 5,  "districts": ["Srinagar", "Jammu", "Anantnag", "Baramulla", "Udhampur"]},
    "Ladakh":               {"seats": 1,  "districts": ["Leh"]},
    "Lakshadweep":          {"seats": 1,  "districts": ["Kavaratti"]},
    "Puducherry":           {"seats": 1,  "districts": ["Puducherry"]},
}

# ─── Work Categories & Subcategories ─────────────────────────────────────────
WORK_CATEGORIES = {
    "Road": ["Bituminous Road Construction", "CC Road Construction", "Road Repair & Resurfacing", "Footpath Construction", "Culvert Construction", "Bridge Repair"],
    "Healthcare": ["Primary Health Centre", "Sub-Centre Construction", "Ambulance Purchase", "Medical Equipment Purchase", "Community Health Centre Upgrade"],
    "Education": ["School Building Construction", "Classroom Addition", "Computer Lab Setup", "Library Construction", "Toilet Block Construction", "Boundary Wall Construction"],
    "Water Supply": ["Borewell Installation", "Overhead Tank Construction", "Pipeline Laying", "RO Plant Installation", "Hand Pump Installation", "Water Purification Unit"],
    "Sanitation": ["Community Toilet Block", "Drainage Construction", "Sewage Treatment", "Solid Waste Management", "Open Drain to Closed Drain"],
    "Electricity": ["Street Light Installation", "Solar Light Installation", "Transformer Installation", "Electrical Line Extension", "LED Street Light Replacement"],
    "Community": ["Community Hall Construction", "Cremation Ground Development", "Bus Shelter Construction", "Park Development", "Playground Construction", "Market Shed Construction"],
    "Sports": ["Stadium Development", "Sports Equipment Purchase", "Indoor Stadium Construction", "Gymnasium Construction", "Swimming Pool Construction"],
}

PARTIES = ["BJP", "INC", "TMC", "DMK", "YSR Congress", "BJD", "AAP", "SP", "BSP", "NCP", "SHS", "TDP", "JDU", "RJD", "AITC", "CPI(M)", "Independent", "Others"]
CONSTITUENCY_TYPES = ["General", "SC", "ST"]
HOUSES = ["Lok Sabha"]


def load_existing_mp_data():
    """Load the existing MP allocation CSV as seed data."""
    csv_path = os.path.join(OUTPUT_DIR, "MPLADS_MP_Allocated_Limit_Analysis.csv")
    if os.path.exists(csv_path):
        df = pd.read_csv(csv_path)
        print(f"  Loaded existing MP data: {len(df)} records from {df['State'].nunique()} states")
        return df
    else:
        print(f"  Existing CSV not found at {csv_path}, generating from scratch")
        return None


def generate_mp_table(existing_df=None):
    """Generate comprehensive MP table covering all states/UTs."""
    print("\nGenerating MP Table...")
    
    mp_records = []
    mp_id = 1
    
    if existing_df is not None:
        # Use existing records as base
        for _, row in existing_df.iterrows():
            state = row["State"]
            # Assign utilization based on deviation
            allocated = row["Allocated_Amount"]
            deviation_pct = row.get("Deviation_Pct", 0)
            
            # Generate realistic utilization rate
            # CAG avg is ~33.9%, distribute around that
            if deviation_pct > 50:
                utilization = np.random.uniform(15, 35)
            elif deviation_pct > 20:
                utilization = np.random.uniform(25, 55)
            elif deviation_pct > 0:
                utilization = np.random.uniform(30, 70)
            else:
                utilization = np.random.uniform(20, 90)
            
            # Determine risk tier
            if utilization < 40:
                risk_tier = "High Risk"
            elif utilization < 65:
                risk_tier = "Moderate Risk"
            else:
                risk_tier = "Clean / Exemplary"
            
            mp_records.append({
                "mp_id": mp_id,
                "mp_name": row["MP_Name"],
                "state": state,
                "constituency": row["Constituency"],
                "constituency_type": row.get("Constituency_Type", np.random.choice(CONSTITUENCY_TYPES, p=[0.7, 0.2, 0.1])),
                "house": "Lok Sabha",
                "party": np.random.choice(PARTIES, p=[0.30, 0.15, 0.08, 0.06, 0.05, 0.04, 0.03, 0.05, 0.03, 0.03, 0.03, 0.03, 0.03, 0.02, 0.02, 0.01, 0.02, 0.02]),
                "allocated_amount": allocated,
                "released_amount": allocated * np.random.uniform(0.80, 1.0),
                "expenditure_amount": allocated * (utilization / 100),
                "utilization_pct": round(utilization, 2),
                "total_works_recommended": int(np.random.uniform(15, 80)),
                "total_works_completed": 0,  # Will be calculated
                "risk_tier": risk_tier,
                "deviation_pct": deviation_pct,
            })
            mp_id += 1
    
    # Calculate completed works ratio based on risk tier
    for rec in mp_records:
        total = rec["total_works_recommended"]
        if rec["risk_tier"] == "High Risk":
            rec["total_works_completed"] = int(total * np.random.uniform(0.15, 0.45))
        elif rec["risk_tier"] == "Moderate Risk":
            rec["total_works_completed"] = int(total * np.random.uniform(0.40, 0.70))
        else:
            rec["total_works_completed"] = int(total * np.random.uniform(0.65, 0.95))
    
    mp_df = pd.DataFrame(mp_records)
    
    # ─── Cleaning ─────────────────────────────────────────────────────────────
    mp_df["mp_name"] = mp_df["mp_name"].str.strip().str.title()
    mp_df["state"] = mp_df["state"].str.strip().str.title()
    mp_df["constituency"] = mp_df["constituency"].str.strip().str.upper()
    
    # Remove duplicates
    mp_df = mp_df.drop_duplicates(subset=["mp_name", "constituency"])
    
    # Fill any NaN
    mp_df = mp_df.fillna(0)
    
    # Sort by state
    mp_df = mp_df.sort_values(["state", "mp_name"]).reset_index(drop=True)
    mp_df["mp_id"] = range(1, len(mp_df) + 1)
    
    print(f"  Generated {len(mp_df)} MP records across {mp_df['state'].nunique()} states/UTs")
    print(f"  Risk Distribution:")
    for tier, count in mp_df["risk_tier"].value_counts().items():
        pct = count / len(mp_df) * 100
        print(f"     • {tier}: {count} ({pct:.1f}%)")
    
    return mp_df


def generate_work_table(mp_df):
    """Generate 15,000 work-level records with realistic features."""
    print(f"\n Generating {NUM_WORKS} Work Records...")
    
    num_anomalous = int(NUM_WORKS * ANOMALY_RATIO)
    num_clean = NUM_WORKS - num_anomalous
    
    works = []
    work_id = 1
    
    # Distribute works across MPs proportionally (weighted by state seats)
    mp_weights = mp_df["total_works_recommended"].values / mp_df["total_works_recommended"].sum()
    mp_indices = np.random.choice(len(mp_df), size=NUM_WORKS, p=mp_weights)
    
    # Assign anomaly labels (use Python list, NOT numpy array, to avoid <U5 truncation)
    labels = ["clean"] * NUM_WORKS
    anomalous_indices = np.random.choice(NUM_WORKS, size=num_anomalous, replace=False)
    
    # Distribute anomaly types
    anomaly_type_list = []
    for atype, ratio in ANOMALY_TYPES.items():
        count = int(num_anomalous * ratio)
        anomaly_type_list.extend([atype] * count)
    # Fill remainder
    while len(anomaly_type_list) < num_anomalous:
        anomaly_type_list.append(np.random.choice(list(ANOMALY_TYPES.keys())))
    np.random.shuffle(anomaly_type_list)
    
    for idx, anom_idx in enumerate(anomalous_indices):
        labels[anom_idx] = anomaly_type_list[idx]
    
    for i in range(NUM_WORKS):
        mp_row = mp_df.iloc[mp_indices[i]]
        state = mp_row["state"]
        state_key = state.strip()
        
        # Find state districts
        districts = ["Unknown"]
        for sname, sdata in STATES_AND_UTS.items():
            if sname.lower().strip() == state_key.lower().strip():
                districts = sdata["districts"]
                break
        
        district = np.random.choice(districts)
        
        # Select work category
        category = np.random.choice(list(WORK_CATEGORIES.keys()), 
                                     p=[0.25, 0.12, 0.18, 0.15, 0.08, 0.07, 0.10, 0.05])
        subcategory = np.random.choice(WORK_CATEGORIES[category])
        
        # ─── Generate features based on anomaly status ────────────────────────
        label = labels[i]
        is_anomalous = 0 if label == "clean" else 1
        anomaly_type = label if is_anomalous else "clean"
        
        if is_anomalous:
            work = _generate_anomalous_work(anomaly_type, category)
        else:
            work = _generate_clean_work(category)
        
        works.append({
            "work_id": f"W{work_id:06d}",
            "mp_id": mp_row["mp_id"],
            "mp_name": mp_row["mp_name"],
            "state": state,
            "district": district,
            "constituency": mp_row["constituency"],
            "constituency_type": mp_row["constituency_type"],
            "house": "Lok Sabha",
            "party": mp_row["party"],
            "work_category": category,
            "work_subcategory": subcategory,
            **work,
            "is_anomalous": is_anomalous,
            "anomaly_type": anomaly_type,
        })
        work_id += 1
    
    work_df = pd.DataFrame(works)
    
    # ─── Cleaning ─────────────────────────────────────────────────────────────
    # Round financial columns to 2 decimal places
    for col in ["estimated_cost_inr", "sanctioned_cost_inr", "actual_expenditure_inr"]:
        work_df[col] = work_df[col].round(2)
    
    # Ensure no negative values in cost/time columns
    for col in ["estimated_cost_inr", "sanctioned_cost_inr", "actual_expenditure_inr",
                 "expected_completion_days", "actual_completion_days"]:
        work_df[col] = work_df[col].clip(lower=0)
    
    # Ensure integer columns
    for col in ["expected_completion_days", "actual_completion_days", "inspection_done",
                 "photo_available", "photo_location_match", "similar_work_count_500m", "payment_count"]:
        work_df[col] = work_df[col].astype(int)
    
    # Feature engineering: derived columns
    work_df["cost_overrun_ratio"] = ((work_df["actual_expenditure_inr"] - work_df["sanctioned_cost_inr"]) / 
                                      work_df["sanctioned_cost_inr"].clip(lower=1)).round(4)
    work_df["delay_days"] = (work_df["actual_completion_days"] - work_df["expected_completion_days"]).clip(lower=0)
    work_df["cost_deviation_pct"] = ((work_df["actual_expenditure_inr"] - work_df["estimated_cost_inr"]) / 
                                      work_df["estimated_cost_inr"].clip(lower=1) * 100).round(2)
    
    # Remove any duplicate work_ids
    work_df = work_df.drop_duplicates(subset=["work_id"])
    
    # Sort
    work_df = work_df.sort_values(["state", "mp_name", "work_id"]).reset_index(drop=True)
    
    print(f"  Generated {len(work_df)} work records")
    print(f"  Anomaly Distribution:")
    print(f"     • Clean: {(work_df['is_anomalous'] == 0).sum()} ({(work_df['is_anomalous'] == 0).mean()*100:.1f}%)")
    print(f"     • Anomalous: {(work_df['is_anomalous'] == 1).sum()} ({(work_df['is_anomalous'] == 1).mean()*100:.1f}%)")
    for atype in ANOMALY_TYPES:
        count = (work_df['anomaly_type'] == atype).sum()
        print(f"       - {atype}: {count}")
    
    return work_df


def _generate_clean_work(category):
    """Generate a clean (non-anomalous) work with realistic features."""
    # Base cost ranges by category (in INR)
    cost_ranges = {
        "Road": (500000, 5000000),
        "Healthcare": (1000000, 8000000),
        "Education": (300000, 4000000),
        "Water Supply": (200000, 3000000),
        "Sanitation": (300000, 2500000),
        "Electricity": (100000, 2000000),
        "Community": (500000, 6000000),
        "Sports": (1000000, 10000000),
    }
    
    low, high = cost_ranges.get(category, (500000, 5000000))
    estimated_cost = np.random.uniform(low, high)
    
    # Clean works: sanctioned close to estimated, expenditure close to sanctioned
    sanctioned_cost = estimated_cost * np.random.uniform(0.95, 1.10)
    actual_expenditure = sanctioned_cost * np.random.uniform(0.85, 1.05)
    
    # Completion time
    expected_days = int(np.random.uniform(30, 180))
    actual_days = int(expected_days * np.random.uniform(0.8, 1.3))  # Slight delay OK
    
    return {
        "estimated_cost_inr": estimated_cost,
        "sanctioned_cost_inr": sanctioned_cost,
        "actual_expenditure_inr": actual_expenditure,
        "expected_completion_days": expected_days,
        "actual_completion_days": actual_days,
        "inspection_done": np.random.choice([0, 1], p=[0.15, 0.85]),
        "photo_available": np.random.choice([0, 1], p=[0.10, 0.90]),
        "photo_location_match": np.random.choice([0, 1], p=[0.10, 0.90]),
        "similar_work_count_500m": np.random.choice([0, 1], p=[0.85, 0.15]),
        "payment_count": int(np.random.uniform(1, 5)),
    }


def _generate_anomalous_work(anomaly_type, category):
    """Generate an anomalous work with features matching the anomaly archetype."""
    cost_ranges = {
        "Road": (500000, 5000000),
        "Healthcare": (1000000, 8000000),
        "Education": (300000, 4000000),
        "Water Supply": (200000, 3000000),
        "Sanitation": (300000, 2500000),
        "Electricity": (100000, 2000000),
        "Community": (500000, 6000000),
        "Sports": (1000000, 10000000),
    }
    
    low, high = cost_ranges.get(category, (500000, 5000000))
    estimated_cost = np.random.uniform(low, high)
    
    if anomaly_type == "delay_anomaly":
        sanctioned_cost = estimated_cost * np.random.uniform(0.95, 1.15)
        actual_expenditure = sanctioned_cost * np.random.uniform(0.90, 1.20)
        expected_days = int(np.random.uniform(30, 120))
        actual_days = int(expected_days * np.random.uniform(2.0, 6.0))  # Major delay
        inspection_done = np.random.choice([0, 1], p=[0.40, 0.60])
        photo_available = np.random.choice([0, 1], p=[0.25, 0.75])
        photo_match = np.random.choice([0, 1], p=[0.30, 0.70])
        similar_500m = np.random.choice([0, 1, 2], p=[0.70, 0.20, 0.10])
        payment_count = int(np.random.uniform(3, 10))
        
    elif anomaly_type == "cost_anomaly":
        sanctioned_cost = estimated_cost * np.random.uniform(1.30, 2.50)  # Inflated sanction
        actual_expenditure = sanctioned_cost * np.random.uniform(1.10, 1.80)  # Over-expenditure
        expected_days = int(np.random.uniform(30, 150))
        actual_days = int(expected_days * np.random.uniform(1.0, 2.0))
        inspection_done = np.random.choice([0, 1], p=[0.35, 0.65])
        photo_available = np.random.choice([0, 1], p=[0.20, 0.80])
        photo_match = np.random.choice([0, 1], p=[0.25, 0.75])
        similar_500m = np.random.choice([0, 1, 2], p=[0.75, 0.15, 0.10])
        payment_count = int(np.random.uniform(4, 12))
        
    elif anomaly_type == "duplicate_work":
        sanctioned_cost = estimated_cost * np.random.uniform(0.95, 1.15)
        actual_expenditure = sanctioned_cost * np.random.uniform(0.85, 1.10)
        expected_days = int(np.random.uniform(30, 120))
        actual_days = int(expected_days * np.random.uniform(0.9, 1.5))
        inspection_done = np.random.choice([0, 1], p=[0.30, 0.70])
        photo_available = np.random.choice([0, 1], p=[0.20, 0.80])
        photo_match = np.random.choice([0, 1], p=[0.40, 0.60])
        similar_500m = np.random.choice([2, 3, 4, 5], p=[0.30, 0.35, 0.25, 0.10])  # Key signal
        payment_count = int(np.random.uniform(2, 7))
        
    elif anomaly_type == "ghost_asset":
        sanctioned_cost = estimated_cost * np.random.uniform(1.00, 1.40)
        actual_expenditure = sanctioned_cost * np.random.uniform(0.80, 1.30)
        expected_days = int(np.random.uniform(30, 120))
        actual_days = int(expected_days * np.random.uniform(0.5, 1.5))
        inspection_done = np.random.choice([0, 1], p=[0.75, 0.25])  # Usually no inspection
        photo_available = np.random.choice([0, 1], p=[0.55, 0.45])  # Often no photo
        photo_match = np.random.choice([0, 1], p=[0.80, 0.20])  # GPS mismatch
        similar_500m = np.random.choice([0, 1, 2], p=[0.60, 0.25, 0.15])
        payment_count = int(np.random.uniform(1, 5))
        
    elif anomaly_type == "vendor_anomaly":
        sanctioned_cost = estimated_cost * np.random.uniform(1.10, 1.80)
        actual_expenditure = sanctioned_cost * np.random.uniform(0.95, 1.40)
        expected_days = int(np.random.uniform(45, 150))
        actual_days = int(expected_days * np.random.uniform(1.2, 3.0))
        inspection_done = np.random.choice([0, 1], p=[0.45, 0.55])
        photo_available = np.random.choice([0, 1], p=[0.30, 0.70])
        photo_match = np.random.choice([0, 1], p=[0.35, 0.65])
        similar_500m = np.random.choice([1, 2, 3], p=[0.40, 0.35, 0.25])
        payment_count = int(np.random.uniform(5, 15))  # Suspicious multiple payments
        
    elif anomaly_type == "payment_anomaly":
        sanctioned_cost = estimated_cost * np.random.uniform(1.00, 1.30)
        actual_expenditure = sanctioned_cost * np.random.uniform(1.20, 2.00)  # Over-payment
        expected_days = int(np.random.uniform(30, 120))
        actual_days = int(expected_days * np.random.uniform(0.8, 1.8))
        inspection_done = np.random.choice([0, 1], p=[0.40, 0.60])
        photo_available = np.random.choice([0, 1], p=[0.25, 0.75])
        photo_match = np.random.choice([0, 1], p=[0.30, 0.70])
        similar_500m = np.random.choice([0, 1, 2], p=[0.65, 0.25, 0.10])
        payment_count = int(np.random.uniform(8, 20))  # Excessive payments
    else:
        return _generate_clean_work(category)
    
    return {
        "estimated_cost_inr": estimated_cost,
        "sanctioned_cost_inr": sanctioned_cost,
        "actual_expenditure_inr": actual_expenditure,
        "expected_completion_days": expected_days,
        "actual_completion_days": actual_days,
        "inspection_done": inspection_done,
        "photo_available": photo_available,
        "photo_location_match": photo_match,
        "similar_work_count_500m": similar_500m,
        "payment_count": payment_count,
    }


def generate_risk_leaderboard(mp_df, work_df):
    """Generate MP risk leaderboard ranked by composite risk score."""
    print("\nGenerating MP Risk Leaderboard...")
    
    leaderboard = []
    
    for _, mp in mp_df.iterrows():
        mp_works = work_df[work_df["mp_id"] == mp["mp_id"]]
        
        if len(mp_works) == 0:
            continue
        
        anomaly_rate = mp_works["is_anomalous"].mean()
        avg_cost_overrun = mp_works["cost_overrun_ratio"].mean()
        avg_delay = mp_works["delay_days"].mean()
        inspection_rate = mp_works["inspection_done"].mean()
        photo_rate = mp_works["photo_available"].mean()
        
        # Composite risk score (0-100)
        risk_score = min(100, (
            anomaly_rate * 40 +
            min(1, max(0, avg_cost_overrun)) * 20 +
            min(1, avg_delay / 180) * 15 +
            (1 - inspection_rate) * 15 +
            (1 - photo_rate) * 10
        ) * 100)
        
        leaderboard.append({
            "rank": 0,
            "mp_id": mp["mp_id"],
            "mp_name": mp["mp_name"],
            "state": mp["state"],
            "constituency": mp["constituency"],
            "party": mp["party"],
            "total_works": len(mp_works),
            "anomalous_works": mp_works["is_anomalous"].sum(),
            "anomaly_rate_pct": round(anomaly_rate * 100, 2),
            "avg_cost_overrun_pct": round(avg_cost_overrun * 100, 2),
            "avg_delay_days": round(avg_delay, 1),
            "inspection_rate_pct": round(inspection_rate * 100, 2),
            "utilization_pct": mp["utilization_pct"],
            "risk_score": round(risk_score, 2),
            "risk_tier": mp["risk_tier"],
        })
    
    lb_df = pd.DataFrame(leaderboard)
    lb_df = lb_df.sort_values("risk_score", ascending=False).reset_index(drop=True)
    lb_df["rank"] = range(1, len(lb_df) + 1)
    
    print(f"  Generated leaderboard for {len(lb_df)} MPs")
    print(f"  Top 5 Riskiest MPs:")
    for _, row in lb_df.head().iterrows():
        print(f"     #{row['rank']} {row['mp_name']} ({row['state']}) — Score: {row['risk_score']}")
    
    return lb_df


def main():
    print("=" * 70)
    print("  MPLADS-SATHI: Extended All-States Dataset Generator")
    print("=" * 70)
    
    # Force object dtype for strings to avoid ArrowDtype truncation in pandas 3.0
    try:
        pd.set_option("mode.dtype_backend", "numpy_nullable")
    except Exception:
        pass
    pd.set_option("future.infer_string", False)
    
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # Step 1: Load existing data
    existing_df = load_existing_mp_data()
    
    # Step 2: Generate MP table
    mp_df = generate_mp_table(existing_df)
    
    # Step 3: Generate work table
    work_df = generate_work_table(mp_df)
    
    # Step 4: Generate risk leaderboard
    lb_df = generate_risk_leaderboard(mp_df, work_df)
    
    # Step 5: Save outputs
    print("\nSaving datasets...")
    
    mp_path = os.path.join(OUTPUT_DIR, "mplads_mp_table.csv")
    mp_df.to_csv(mp_path, index=False)
    print(f"  Saved: {mp_path} ({len(mp_df)} rows, {mp_df.shape[1]} cols)")
    
    work_path = os.path.join(OUTPUT_DIR, "mplads_work_table.csv")
    work_df.to_csv(work_path, index=False)
    print(f"  Saved: {work_path} ({len(work_df)} rows, {work_df.shape[1]} cols)")
    
    lb_path = os.path.join(OUTPUT_DIR, "mplads_mp_risk_leaderboard.csv")
    lb_df.to_csv(lb_path, index=False)
    print(f"  Saved: {lb_path} ({len(lb_df)} rows, {lb_df.shape[1]} cols)")
    
    # Step 6: Summary stats
    print("\n" + "=" * 70)
    print("  DATASET SUMMARY")
    print("=" * 70)
    print(f"  Total MPs:              {len(mp_df)}")
    print(f"  Total States/UTs:       {mp_df['state'].nunique()}")
    print(f"  Total Works:            {len(work_df)}")
    print(f"  Clean Works:            {(work_df['is_anomalous'] == 0).sum()} ({(work_df['is_anomalous'] == 0).mean()*100:.1f}%)")
    print(f"  Anomalous Works:        {(work_df['is_anomalous'] == 1).sum()} ({(work_df['is_anomalous'] == 1).mean()*100:.1f}%)")
    print(f"  Work Categories:        {work_df['work_category'].nunique()}")
    print(f"  Avg Utilization:        {mp_df['utilization_pct'].mean():.1f}%")
    print(f"  High Risk MPs:          {(mp_df['risk_tier'] == 'High Risk').sum()}")
    print(f"  Moderate Risk MPs:      {(mp_df['risk_tier'] == 'Moderate Risk').sum()}")
    print(f"  Clean/Exemplary MPs:    {(mp_df['risk_tier'] == 'Clean / Exemplary').sum()}")
    print("=" * 70)
    print("  Dataset generation complete!")


if __name__ == "__main__":
    main()
